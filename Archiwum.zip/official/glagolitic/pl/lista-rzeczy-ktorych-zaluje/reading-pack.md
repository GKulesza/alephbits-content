# Lista rzeczy, których żałuję

## Metadata

**Pack ID:** `polish_lista_rzeczy_ktorych_zaluje`  
**Version:** 1.0.0  
**Edition version:** 1.0.0  

**Title:** Lista rzeczy, których żałuję  
**Subtitle:** Regret list matki dorosłych dzieci  
**Blurb:** Anna ma 42 lata i listę jedenaastu rodzicielskich żalów. Syn Tomek wraca na weekend i pokazuje, że miłość przetrwała mimo błędów.

**Genres:** psychology, short_story  
**Series:** Collection Ten  
**Audience:** adult

**Difficulty:** 4 (of 8)  
**Reader difficulty:** ★★★☆☆  
**Estimated reading time:** 7 minutes

**Publication date:** *(original — 2026)*  
**Historical period:** contemporary  

**Original language:** pl  
**Translation summary:** Lista rzeczy, których żałuję — Collection Ten official reading pack (Polish).  

**Writing system:** glagolitic  
**Recommended profile:** polish_default  
**Recommended level:** 2  

**Tags:** żal, macierzyństwo, relacja z dorosłym dzieckiem, Collection Ten  

**Keywords:** Lista żalów, Anna, Tomek, macierzyństwo  

**Cover family:** everyday_live


**Motifs:**
- motherhood
- grief
- memory
- photograph
- forgiveness
- gratitude

**Editorial notes:** Tytuł podobny do C9 „Lista” — inna fabuła; slug rozróżnia.

**Inspiration:** Refleksja matki dorosłych dzieci nad rodzicielskimi żalami; YouTube rqugxbDkCro (2019-06-23).

---

**World:**
- objects: book, window
- places: home

## Editorial Transparency

**Created by:** AlephBits Editorial  
**Editor:** AlephBits Editorial  
**LLM assisted:** yes  
**LLM model:** Claude  
**Human reviewed:** yes — 2026-07-13  
**Trust classification:** Fiction  
**License:** CC0 1.0 Universal (SPDX: CC0-1.0)  
**License URL:** https://creativecommons.org/publicdomain/zero/1.0/  
**Source block:** 23.06.2019 -> https://www.youtube.com/watch?v=rqugxbDkCro  
**Revision notes:** Phase 119 import.

### Revision history

| Version | Date | Note |
|---------|------|------|
| 1.0.0 | 2026-07-13 | Collection editorial import (Phase 119) |

### Editorial history

| Date | Editor | Note |
|------|--------|------|
| 2026-07-13 | AlephBits Editorial | Phase 119 import; philosophy fit 3/5 — Poruszająca, melancholijna; mniej encourage exploration niż Jeszcze. |

---

## Sources

### Source 1: Collection Ten manuscript

**Author:** AlephBits Editorial (adaptation)  
**URL:** https://www.youtube.com/watch?v=rqugxbDkCro  
**License:** CC0 1.0 Universal (text); source material per original availability  
**Retrieval date:** 2019-06-23  
**Availability:** adaptation  
**Deprecated:** no  
**Editor notes:** Materiał źródłowy wskazany w bloku source manuskryptu; tekst jest adaptacją redakcyjną.

---

## Text

**LISTA RZECZY, KTÓRYCH ŻAŁUJĘ**

Anna miała czterdzieści dwa lata i dwoje dorosłych dzieci. Kiedy patrzyła wstecz, widziała lata, które minęły jak jeden dzień. I widziała błędy, które popełniła. Nie wielkie, nie dramatyczne – takie codzienne, drobne, które składają się na całe życie.

Siedziała w kuchni z kubkiem herbaty, patrząc na stare zdjęcia, które właśnie znalazła w szafie. Na jednym z nich jej syn Tomek miał pięć lat i uśmiechał się od ucha do ucha. Trzymał w ręku plastelinowego dinozaura, którego sam ulepił. Anna pamiętała ten dzień. Pamiętała, że była zmęczona, że miała mnóstwo pracy, że krzyknęła na Tomka, bo rozsypał plastelinę na dywanie.

– Znowu narobiłeś bałaganu – powiedziała wtedy. – Ile razy mam ci mówić, żebyś był ostrożny?

Tomek spuścił wzrok. Dinozaur wylądował w koszu. Anna nie pamiętała, co się stało później. Pamiętała tylko jego oczy – smutne, zawiedzione, zagubione.

Przypomniała sobie słowa z filmu, który niedawno obejrzała. Mówili o rzeczach, których rodzice żałują. O zbyt częstym strofowaniu. O przegapionych momentach. O braku przytulania.

Anna odłożyła zdjęcie i spojrzała na swoje dłonie. Zastanawiała się, ile razy mogła zrobić coś inaczej. I czy w ogóle można cofnąć czas.

---
Tomek miał teraz dwadzieścia dwa lata. Studiował w innym mieście, przyjeżdżał na święta i urodziny. Rozmawiali przez telefon, ale Anna czuła, że coś między nimi pękło. Nie było już tej bliskości, którą pamiętała z jego dzieciństwa.

Pewnego dnia, podczas świątecznego obiadu, Anna zapytała:

– Tomku, pamiętasz, jak byłeś mały?

– Co konkretnie?

– No, jak robiliśmy razem różne rzeczy. Jak chodziliśmy na spacery, jak czytaliśmy książki.

Tomek uśmiechnął się, ale w jego oczach było coś, czego Anna nie umiała nazwać.

– Pamiętam, że zawsze byłaś zmęczona – powiedział. – I że często się denerwowałaś. Pamiętam, jak krzyczałaś na mnie, że znowu rozsypałem plastelinę.

Anna poczuła, jak coś ściska ją w gardle.

– Ja… ja nie chciałam – powiedziała. – Po prostu byłam zmęczona.

– Wiem. I nie mam do ciebie żalu. Ale pamiętam to. I pamiętam, że kiedyś obiecałaś, że pójdziemy do kina, ale nie poszłaś, bo miałaś ważne spotkanie.

Anna zamknęła oczy. Pamiętała to. Pamiętała, jak Tomek stał w drzwiach w kurtce, gotowy do wyjścia. I jak ona, w pośpiechu, powiedziała: "Przepraszam, synku, muszę odwołać. Mama ma pilną sprawę."

– Przepraszam – powiedziała cicho.

– Nie musisz przepraszać – odpowiedział Tomek. – To było dawno temu. Po prostu… chyba zawsze myślałem, że jestem mniej ważny niż twoja praca.

Anna milczała. Wiedziała, że to nieprawda. Ale wiedziała też, że tak to wyglądało z perspektywy dziecka.

---
Tego wieczoru Anna usiadła przed komputerem. Włączyła notatnik i zaczęła pisać.

_Lista rzeczy, których żałuję._

_1. Zbyt często strofowałam Tomka. Za każdy drobiazg, za każdy bałagan, za każdą pomyłkę. Zamiast go wspierać, krytykowałam. Zamiast uczyć, karałam._

_2. Przegapiłam najważniejsze momenty. Jego pierwszy występ w szkole, jego pierwszy mecz, jego pierwszy dzień w nowej szkole. Zawsze miałam ważniejsze sprawy._

_3. Nie spędzaliśmy razem czasu na twórczych zabawach. Kiedyś, gdy był mały, uwielbiał rysować. A ja mówiłam: "Zostaw to, rób lekcje"._

_4. Nie robiłam zdjęć. Nie nagrywałam filmów. Myślałam, że będę pamiętać wszystko. Ale nie pamiętam. Zostały tylko mgliste obrazy._

_5. Nie brałam pod uwagę jego opinii. Mówiłam: "Jesteś dzieckiem, nie masz zdania". A potem dziwiłam się, że nigdy nie mówił, co myśli._

_6. Nie czerpałam przyjemności z kontaktu z nim. Zamiast się nim cieszyć, martwiłam się o obowiązki, o pracę, o to, co jeszcze mam do zrobienia._

_7. Nie edukowałam go o pieniądzach. Mówiłam: "Nie stać nas", ale nie tłumaczyłam dlaczego. Potem, gdy zaczął zarabiać, wydawał wszystko, co miał._

_8. Nie dbałam o jego szczęście. Myślałam, że najważniejsze są oceny, sukcesy, przyszłość. Zapomniałam, że dzieciństwo ma być radosne._

_9. Nie przytulałam go wystarczająco często. Myślałam, że jak będzie starszy, to nie będzie chciał. I miałam rację. Przestał chcieć, zanim się zorientowałam._

_10. Byłam niekonsekwentna. Raz mówiłam "nie", a potem "tak". Raz karałam, a potem odpuszczałam. Dziecko nie wiedziało, czego się spodziewać._

_11. Słuchałam cudzych rad. Sąsiadka mówiła, że trzeba być surowym. Ciocia mówiła, że trzeba być czułym. A ja, zagubiona, próbowałam zadowolić wszystkich. Zapomniałam, że to ja jestem mamą._

Anna przeczytała listę. Była długa. I bolesna. Ale nie napisała jej, żeby się obwiniać. Napisała ją, żeby zrozumieć. I żeby coś zmienić.

---
Następnego dnia zadzwoniła do Tomka.

– Synku, mam do ciebie prośbę – powiedziała.

– Słucham.

– Chciałabym, żebyśmy spędzili razem weekend. Tylko my. Bez pracy, bez obowiązków. Chciałabym nadrobić stracony czas.

Tomek milczał przez chwilę.

– To miłe, mamo – powiedział w końcu. – Ale nie musisz tego robić. Wiem, że jesteś zajęta.

– Nie jestem zajęta – odpowiedziała. – I nie robię tego z obowiązku. Robię to, bo chcę. Bo tęsknię za tobą. I bo chcę, żebyś wiedział, że zawsze byłeś dla mnie najważniejszy. Nawet jeśli nie zawsze to pokazywałam.

Tomek milczał dłużej tym razem.

– Dobrze – powiedział w końcu. – Przyjadę.

---
Weekend spędzili razem. Poszli do kina, na spacer, do muzeum. Anna nie patrzyła na telefon. Nie myślała o pracy. Była tylko z nim.

Wieczorem, gdy siedzieli przy herbacie, Tomek powiedział:

– Mamo, pamiętasz, jak kiedyś mówiłaś, że żałujesz, że nie robiłaś zdjęć?

– Pamiętam.

– Zrobiłem coś. Chciałbym ci pokazać.

Tomek wyjął telefon i pokazał jej album. Zdjęcia, które znalazł w starych pudłach, zeskanował i uporządkował. Były tam zdjęcia z jego dzieciństwa – te, których Anna nie pamiętała, bo ich nie zrobiła. Ale były też te, które zrobiła. Uśmiechy, śmiechy, chwile, które przetrwały.

– Skąd to masz? – zapytała Anna, ocierając łzy.

– Znalazłem w twojej szafie – powiedział Tomek. – I pomyślałem, że warto to zachować. To są nasze wspomnienia. Nawet jeśli nie wszystkie są idealne, to są nasze.

Anna przytuliła syna. Pierwszy raz od wielu lat.

– Przepraszam – powiedziała.

– Za co?

– Za wszystko. Za to, że nie było mnie, kiedy potrzebowałeś. Za to, że za bardzo się starałam być idealną mamą, zamiast być po prostu mamą. I za to, że dopiero teraz to rozumiem.

Tomek przytulił ją mocniej.

– Nie musisz przepraszać – powiedział. – Jesteś moją mamą. I zawsze będziesz.

---
Kilka dni później Anna wróciła do listy. Przeczytała ją jeszcze raz. I zamiast się smucić, postanowiła coś z nią zrobić. Zaczęła od numeru 6 – "Nie czerpałam przyjemności z kontaktu z dziećmi".

Zadzwoniła do swojej córki, która mieszkała za granicą. Rozmawiały przez dwie godziny. Śmiały się, płakały, wspominały. Anna nie spieszyła się. Nie miała ważniejszych spraw.

Potem numer 9 – "Nie przytulałam dziecka wystarczająco często". Następnym razem, gdy zobaczyła Tomka, przytuliła go tak mocno, jak tylko mogła.

Numer 2 – "Przegapiłam najważniejsze momenty". Postanowiła, że od teraz będzie obecna. Na każdym ważnym wydarzeniu, na każdym spotkaniu, na każdej rozmowie.

Numer 11 – "Słuchałam cudzych rad". Postanowiła zaufać sobie. Wiedziała, że jako matka ma instynkt, który ją nie zawiedzie.

I numer 1 – "Zbyt często strofowałam". Zaczęła mówić do swoich dzieci inaczej. Zamiast krytykować, wspierać. Zamiast karać, tłumaczyć.

Nie wszystko dało się naprawić. Niektóre błędy pozostały. Ale Anna wiedziała, że najważniejsze jest to, żeby próbować. I żeby dzieci wiedziały, że są kochane. Bezwarunkowo.

---
Pewnego dnia Tomek napisał do niej wiadomość.

_Mamo, pamiętasz tę listę, którą napisałaś?_

_Pamiętam._

_Przeczytałem ją. I wiesz co? Nie jestem zły. Jestem wdzięczny. Bo to, co napisałaś, pokazuje, że ci zależy. Że chcesz być lepsza. I że mnie kochasz. To najważniejsze._

Anna uśmiechnęła się przez łzy.

_Kocham cię, synku. Zawsze._

_Ja ciebie też, mamo._

Anna zamknęła telefon. Spojrzała na zdjęcie, które stało na biurku – Tomek w wieku pięciu lat z plastelinowym dinozaurem. I pomyślała o tym, że choć nie może cofnąć czasu, to może sprawić, że przyszłość będzie inna.

I że to, co najważniejsze, już ma – miłość, która przetrwała wszystkie błędy.

**KONIEC**

---

## Quiz

**Quiz title:** Sprawdź zrozumienie

### Question 1

**Question:** Ile lat ma Anna?

**Answers:**
- A) 32
- B) 42
- C) 52
- D) 38

**Correct:** B
**Explanation:** Tekst: „Anna miała czterdzieści dwa lata”.
**Text reference:** czterdzieści dwa lata

### Question 2

**Question:** Co Tomek pamięta z dzieciństwa bolesnego dla Anny?

**Answers:**
- A) Tylko prezenty
- B) Że mama często krzyczała i odwołała wyjście do kina
- C) Tylko wakacje
- D) Nic

**Correct:** B
**Explanation:** Tomek wspomina krzyk i odwołane kino.
**Text reference:** odwołać wyjście do kina

### Question 3

**Question:** Po co Anna pisze listę?

**Answers:**
- A) Dla sąsiadów
- B) By zrozumieć błędy i coś zmienić — nie by się obwiniać
- C) Dla sądu
- D) Dla szkoły

**Correct:** B
**Explanation:** Napisała listę, żeby zrozumieć i zmienić, nie by się obwiniać.
**Text reference:** żeby zrozumieć

### Question 4

**Question:** Co Tomek robi ze starymi zdjęciami?

**Answers:**
- A) Wyrzuca je
- B) Skanuje i porządkuje album wspomnień
- C) Sprzedaje
- D) Palą

**Correct:** B
**Explanation:** Tomek skanuje zdjęcia z pudła — „nasze wspomnienia”.
**Text reference:** zeskanował

### Question 5

**Question:** Co Tomek pisze o liście żalów?

**Answers:**
- A) Jest zły
- B) Jest wdzięczny — widać, że mamie zależy i ją kocha
- C) Ignoruje matkę
- D) Chce pieniędzy

**Correct:** B
**Explanation:** Tomek: lista pokazuje, że zależy i kocha — to najważniejsze.
**Text reference:** Jestem wdzięczny


---

## Future Extensions

### Images
*(none)*

### Illustrations
*(none)*

### Audio narration
*(none)*

### Pronunciation
*(none)*

### Handwriting
*(none)*

### Exercises
*(none)*

### Vocabulary
*(none)*
