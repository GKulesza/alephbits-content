# Ikonka na pulpicie

## Metadata

**Pack ID:** `polish_ikonka_na_pulpicie`  
**Version:** 1.0.0  
**Edition version:** 1.0.0  

**Title:** Ikonka na pulpicie  
**Subtitle:** Małżeństwo, ikonka i pytanie zamiast zgadywania  
**Blurb:** Adam idzie do terapeutki, bo czuje, że zna żonę na wylot — i przez to przestaje słuchać. Opowieść o ikonce na pulpicie: klikasz i od razu wiesz, co będzie w pliku, zamiast zapytać, co naprawdę myśli.

**Genres:** psychology, short_story  
**Series:** Collection Eight  
**Audience:** adult

**Difficulty:** 4 (of 8)  
**Reader difficulty:** ★★☆☆☆  
**Estimated reading time:** 6 minutes

**Publication date:** *(original — 2026)*  
**Historical period:** contemporary  

**Original language:** pl  
**Translation summary:** Ikonka na pulpicie — Collection Eight official reading pack (Polish).  

**Writing system:** glagolitic  
**Recommended profile:** polish_default  
**Recommended level:** 2  

**Tags:** małżeństwo, terapia, komunikacja, Collection Eight  

**Keywords:** ikonka na pulpicie, Adam, Magda, małżeństwo, terapia  

**Cover family:** psychology

**Editorial notes:** Fikcja o długich związkach; blisko „Froteryzmu intelektualnego” — inny slug.

**Inspiration:** Metafora ikonki; terapia par.

---

**World:**
- objects: window
- places: home, office

## Editorial Transparency

**Created by:** AlephBits Editorial  
**Editor:** AlephBits Editorial  
**LLM assisted:** yes  
**LLM model:** Claude  
**Human reviewed:** yes — 2026-07-12  
**Trust classification:** Fiction  
**License:** CC0 1.0 Universal (SPDX: CC0-1.0)  
**License URL:** https://creativecommons.org/publicdomain/zero/1.0/  
**Source block:** 14.05.2026 -> https://www.youtube.com/watch?v=Mlunu1IKmYE  
**Revision notes:** Phase 102 import.

### Revision history

| Version | Date | Note |
|---------|------|------|
| 1.0.0 | 2026-07-12 | Collection editorial import (Phase 102) |

### Editorial history

| Date | Editor | Note |
|------|--------|------|
| 2026-07-12 | AlephBits Editorial | Phase 102 import; philosophy fit 4/5 — Dobra metafora komunikacji; praktyczna refleksja dla dorosłych. |

---

## Sources

### Source 1: Collection Eight manuscript

**Author:** AlephBits Editorial (adaptation)  
**URL:** https://www.youtube.com/watch?v=Mlunu1IKmYE  
**License:** CC0 1.0 Universal (text); source material per original availability  
**Retrieval date:** 2026-05-14  
**Availability:** adaptation  
**Deprecated:** no  
**Editor notes:** Materiał źródłowy wskazany w bloku source manuskryptu; tekst jest adaptacją redakcyjną.

---

## Text

**IKONKA NA PULPICIE**

## I. POCZĄTEK

Adam siedział w poczekalni gabinetu terapeutycznego i patrzył na swoje dłonie. Miały 47 lat, były spracowane, ale wciąż silne. Trzymał w nich telefon, na którym otwarta była aplikacja do zarządzania czasem. Plan na dzisiaj: 9:00 – spotkanie z terapeutką. 10:30 – powrót do domu. 11:00 – rozmowa z żoną. 12:00 – decyzja.

— Panie Adamie? — usłyszał głos zza drzwi. — Zapraszam.

Wstał, wszedł do gabinetu i usiadł na wygodnym fotelu. Przed nim siedziała kobieta około pięćdziesiątki z ciepłymi oczami i notatnikiem w ręku.

— Opowiedz mi, co się dzieje — powiedziała.

Adam wziął głęboki oddech.

— Moja żona i ja jesteśmy razem od piętnastu lat. Mamy dwójkę dzieci, dom, kredyt, wszystko, co powinno być. I wydaje mi się, że... że coś się zepsuło.

— Co to znaczy "coś się zepsuło"?

— Nie wiem. — Adam spojrzał na swoje dłonie. — Kiedyś, gdy wracałem do domu, cieszyłem się, że ją zobaczę. Teraz... teraz mam wrażenie, że wiem, co powie, zanim jeszcze otworzy usta. I to nie jest tak, że mówi coś złego. Po prostu... wiem. I to mnie męczy.

Terapeutka skinęła głową.

— To, co opisujesz, jest bardzo typowe dla długich związków. Im dłużej znamy kogoś, tym bardziej zaczynamy zakładać, że wiemy, co myśli. I często zakładamy to, co najgorsze.

— I co mam z tym zrobić?

— Może zacznijmy od tego, co czujesz, kiedy twoja żona mówi coś, co już słyszałeś. Co pojawia się w twojej głowie?

Adam zamknął oczy. W jego głowie pojawił się obraz – ikonka na pulpicie komputera, którą ktoś kliknął. I od razu otworzył się plik, który znał na pamięć.

— Myślę, że znowu zaczyna. Że będzie narzekać na pracę, na dzieci, na to, że nie pomagam. I wiem, że to, co powie, będzie brzmiało jak wyrzut. Nawet jeśli nie ma takiej intencji.

— I co wtedy robisz?

— Zamykam się. Albo odpowiadam czymś, co ją zrani. A potem przepraszam. I tak w kółko.

Terapeutka pochyliła się do przodu.

— A gdybyś spróbował czegoś innego? Gdybyś, zamiast zakładać, że wiesz, co powie, zapytał ją, co naprawdę myśli? I gdybyś spróbował jej uwierzyć?

Adam spojrzał na nią z niedowierzaniem.

— To takie proste?

— Nie — odpowiedziała. — To bardzo trudne. Ale może właśnie tego potrzebujesz.

---
## II. ROZWINIĘCIE

Adam wrócił do domu o 10:30. Żona, Magda, stała w kuchni, gotując obiad. Na blacie leżały składniki na rosół – jej ulubiona zupa, którą gotowała, gdy chciała się zrelaksować. Zapach rosołu przypomniał mu o początku ich związku, kiedy wszystko było nowe, ekscytujące, nieprzewidywalne.

— Cześć — powiedział, wchodząc.

— Cześć — odpowiedziała, nie odwracając się. — Jak było u terapeutki?

— Dobrze. Mówiła, że powinniśmy spróbować bardziej się słuchać.

Magda odwróciła się i spojrzała na niego z mieszaniną ciekawości i niepokoju.

— Czyli... co? Chcesz mi coś powiedzieć?

Adam usiadł przy stole. Przez chwilę patrzył na swoje dłonie, a potem na nią.

— Chcę cię zapytać o coś. I proszę, żebyś nie myślała, że to jakiś wyrzut. Po prostu... chcę zrozumieć.

— O co chodzi?

— Dlaczego ostatnio tak często gotujesz rosół?

Magda spojrzała na niego ze zdziwieniem.

— Bo lubię rosół. I myślałam, że ty też go lubisz.

— Lubię. Ale... — Adam zawahał się. — Wydaje mi się, że gotujesz go wtedy, gdy jesteś smutna. Albo gdy chcesz mi coś powiedzieć, ale nie wiesz jak.

Magda milczała przez chwilę. Potem podeszła do stołu i usiadła naprzeciwko niego.

— Masz rację — powiedziała cicho. — Gotuję go, gdy czuję się samotna. Gdy myślę o tym, że nasze życie stało się takie... takie przewidywalne. Że wiem, co powiesz, zanim jeszcze otworzysz usta. I że to mnie przeraża.

Adam poczuł, że coś w nim pęka. Nie gniew, nie żal – coś innego. Zrozumienie, że przez cały czas robili to samo: zakładali, że wiedzą, co drugie myśli, zamiast po prostu zapytać.

— Ja też tak mam — powiedział. — Myślę, że wiem, co powiesz, i zamykam się. A potem ty się zamykasz. I tak kręcimy się w kółko.

— Co mamy zrobić? — zapytała.

— Może spróbować przestać zgadywać. I zacząć pytać.

---
## III. PUNKT ZWROTNY

Tydzień później Adam i Magda siedzieli na kanapie, oglądając film, który oboje już widzieli. Adam trzymał pilota w ręku i nagle, bez powodu, wcisnął pauzę.

— Co się stało? — zapytała Magda.

— Chciałem cię o coś zapytać. I proszę, nie myśl, że to kolejny wyrzut.

— Dobrze.

— Czy ty czasami myślisz o rozstaniu?

Magda spojrzała na niego z mieszaniną zdziwienia i bólu.

— Myślisz, że chcę się z tobą rozstać?

— Nie wiem. Dlatego pytam.

Magda milczała przez długą chwilę. Potem wzięła jego rękę.

— Myślałam o tym. Kilka razy. Nie dlatego, że nie chcę być z tobą. Ale dlatego, że boję się, że przestaniemy się rozumieć. Że nasze życie stanie się tak przewidywalne, że nie będzie w nim miejsca na nas.

Adam poczuł, że chce mu się płakać. Nie ze smutku – z ulgi, że w końcu powiedziała to, czego oboje bali się wypowiedzieć.

— Ja też myślałem — powiedział. — Nie dlatego, że cię nie kocham. Ale dlatego, że bałem się, że już się nie zmienimy.

— A teraz? — zapytała. — Co teraz?

Adam spojrzał na nią i po raz pierwszy od lat zobaczył ją taką, jaką była na początku. Nie jako kogoś, kogo znał na pamięć, ale jako kogoś, kogo wciąż mógł odkrywać.

— Teraz myślę, że może warto spróbować. Nie udawać, że wszystko jest idealne. Ale po prostu być. I pytać. I słuchać.

Magda uśmiechnęła się.

— To brzmi jak plan.

---
## IV. ZAKOŃCZENIE

Rok później Adam i Magda wciąż byli razem. Nie wszystko było idealne – wciąż się kłócili, wciąż mieli dni, kiedy nie mogli na siebie patrzeć. Ale nauczyli się jednej rzeczy: przestać zgadywać, co drugie myśli, i zacząć pytać.

Pewnego wieczoru, gdy Adam wrócił z pracy, zobaczył Magdę w kuchni. Na blacie leżały składniki na rosół.

— Gotujesz rosół? — zapytał.

— Tak. — Odwróciła się i spojrzała na niego. — Nie dlatego, że jestem smutna. Dlatego, że miałam dobry dzień. I chciałam go uczcić.

Adam uśmiechnął się i podszedł do niej. Objął ją od tyłu, gdy mieszała zupę.

— To dobrze — powiedział. — Bo ja też miałem dobry dzień.

— Opowiesz mi o nim?

— Tak. Ale najpierw chciałbym cię o coś zapytać.

— O co?

— Czy wierzysz, że jeszcze możemy się zmieniać?

Magda odwróciła się i spojrzała mu w oczy.

— Wierzę — odpowiedziała. — Bo już to robimy.

---
## V. EPILOG

Kilka lat później Adam napisał książkę o związkach. Nie o tym, jak być idealnym partnerem, ale o tym, jak przestać udawać, że wiemy wszystko o drugiej osobie.

Na ostatniej stronie napisał:

_"Największym błędem, jaki popełniłem w moim małżeństwie, było myślenie, że znam moją żonę na wylot. Że wiem, co powie, zanim jeszcze otworzy usta. Dopiero gdy przestałem zgadywać i zacząłem pytać, zobaczyłem, że przez cały czas była kimś, kogo wciąż mogłem odkrywać. I to było najpiękniejsze odkrycie mojego życia."_

Kiedy Magda przeczytała te słowa, uśmiechnęła się.

— To prawda — powiedziała. — I nadal cię odkrywam.

Adam wziął ją za rękę.

— I ja ciebie. I mam nadzieję, że nigdy nie przestanę.

---
**KONIEC**

---

## Quiz

**Quiz title:** Sprawdź zrozumienie

### Question 1

**Question:** Ile lat Adam i Magda są razem?

**Answers:**
- A) Pięć
- B) Piętnaście
- C) Trzydzieści
- D) Dwa

**Correct:** B
**Explanation:** Adam mówi o piętnastu latach małżeństwa.
**Text reference:** piętnastu lat

### Question 2

**Question:** Jak Adam opisuje myślenie o żonie?

**Answers:**
- A) Jak czytanie książki
- B) Jak kliknięcie ikonki — od razu otwiera plik, który zna
- C) Jak słuchanie radia
- D) Jak sen

**Correct:** B
**Explanation:** Mówi o ikonce na pulpicie i pliku znanym z góry.
**Text reference:** ikonka na pulpicie

### Question 3

**Question:** Dlaczego Magda gotuje rosół?

**Answers:**
- A) Bo lubi tylko rosół
- B) Bo czuje się samotna, gdy życie staje się przewidywalne
- C) Bo Adam kazał
- D) Bo są goście

**Correct:** B
**Explanation:** Przyznaje, że gotuje rosół, gdy czuje samotność i przewidywalność.
**Text reference:** samotna

### Question 4

**Question:** O co pyta Adam Magdę przy wstrzymanym filmie?

**Answers:**
- A) O wakacje
- B) Czy czasem myśli o rozstaniu
- C) O pracę
- D) O dzieci

**Correct:** B
**Explanation:** Pyta wprost: czy czasem myślisz o rozstaniu?
**Text reference:** rozstaniu

### Question 5

**Question:** Co Adam pisze w książce na końcu?

**Answers:**
- A) Że związki są bez sensu
- B) Że największym błędem było myślenie, że zna żonę na wylot
- C) Że terapia nie działa
- D) Że rozwód jest zły

**Correct:** B
**Explanation:** Pisze o błędzie myślenia, że zna żonę na wylot.
**Text reference:** zna moją żonę na wylot


---

## Future Extensions

### Images
*(none)*

### Illustrations
*(none)*

### Audio narration
*(none)*

### Pronunciation
*(none)*

### Handwriting
*(none)*

### Exercises
*(none)*

### Vocabulary
*(none)*
