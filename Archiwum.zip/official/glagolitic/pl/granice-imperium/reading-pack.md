# Granice Imperium

## Metadata

**Pack ID:** `polish_granice_imperium`  
**Version:** 1.0.0  
**Edition version:** 1.0.0  

**Title:** Granice Imperium  
**Subtitle:** Wykład, zdrada i granice małżeństwa  
**Blurb:** Historyk Adam Wójcicki prowadzi wykład o III Rzeszy w chwili, gdy żona odkrywa jego zdradę. Opowieść splata historię wojny z pytaniem: co się dzieje, gdy system — w państwie i w małżeństwie — boi się zatrzymać i mówić prawdę.

**Genres:** history, psychology, short_story  
**Series:** Collection Seven  
**Audience:** adult

**Difficulty:** 6 (of 8)  
**Reader difficulty:** ★★★☆☆  
**Estimated reading time:** 11 minutes

**Publication date:** *(original — 2026)*  
**Historical period:** contemporary  

**Original language:** pl  
**Translation summary:** Granice Imperium — Collection Seven official reading pack (Polish).  

**Writing system:** glagolitic  
**Recommended profile:** polish_default  
**Recommended level:** 4  

**Tags:** małżeństwo, zdrada, II wojna światowa, granice, Collection Seven  

**Keywords:** Granice Imperium, III Rzesza, zdrada, małżeństwo, granice  

**Cover family:** history

**Editorial notes:** Fikcja łącząca historię militarną z terapią małżeńską; wydarzenia wojenne są narracją edukacyjną, nie prognozą.

**Inspiration:** Manuskrypt Collection Seven; motyw niemieckiej gospodarki wojennej i systemu bez hamulców.

---

**World:**
- objects: book
- places: castle, town

## Editorial Transparency

**Created by:** AlephBits Editorial  
**Editor:** AlephBits Editorial  
**LLM assisted:** yes  
**LLM model:** Claude  
**Human reviewed:** yes — 2026-07-12  
**Trust classification:** Fiction  
**License:** CC0 1.0 Universal (SPDX: CC0-1.0)  
**License URL:** https://creativecommons.org/publicdomain/zero/1.0/  
**Source block:** 05.07.2026 -> https://www.youtube.com/watch?v=v95kpHsD5Hk / 05.07.2026 -> https://www.youtube.com/watch?v=Kpv9w7AICJ4 / 09.07.2026 -> https://www.youtube.com/watch?v=YoBjFdyKKmg  
**Revision notes:** Phase 102 import.

### Revision history

| Version | Date | Note |
|---------|------|------|
| 1.0.0 | 2026-07-12 | Collection editorial import (Phase 102) |

### Editorial history

| Date | Editor | Note |
|------|--------|------|
| 2026-07-12 | AlephBits Editorial | Phase 102 import; philosophy fit 4/5 — Dobre dopasowanie — granice, odpowiedzialność, metafora historyczna służą refleksji, nie sensacji. |

---

## Sources

### Source 1: Collection Seven manuscript

**Author:** AlephBits Editorial (adaptation)  
**URL:** https://www.youtube.com/watch?v=v95kpHsD5Hk  
**License:** CC0 1.0 Universal (text); source material per original availability  
**Retrieval date:** 2026-07-05  
**Availability:** adaptation  
**Deprecated:** no  
**Editor notes:** Materiał źródłowy wskazany w bloku source manuskryptu; tekst jest adaptacją redakcyjną.

---

## Text

**GRANICE IMPERIUM**

## 1. POCZĄTEK

Doktor Adam Wójcicki stał przed czterystuosobową salą wykładową na Uniwersytecie Warszawskim i czuł, że zaraz zemdleje. Nie z powodu tremy – wykładał od piętnastu lat, przyzwyczaił się do spojrzeń studentów. Chodziło o coś innego.

Przed chwilą, podczas przerwy w konferencji historycznej, odebrał telefon od żony. Miała w głosie coś, czego nie słyszał od lat – chłód, który przecinał jak skalpel.

— Adam, musimy porozmawiać. Wróciłam do domu wcześniej. Znalazłam coś na twoim komputerze.

— Co? — zapytał, choć już wiedział. Wiedział od tygodni, odkąd zaczął prowadzić podwójne życie, które sam uważał za "badawczą ekscytację", a które teraz, w świetle słów żony, wyglądało jak najzwyklejsza zdrada.

— Wróć do domu. Teraz.

Rozłączyła się. Adam stał w korytarzu, patrząc na swoje odbicie w szybie – mężczyzna po czterdziestce, w garniturze, z teczką pełną notatek o III Rzeszy. Wyglądał jak ktoś, kto kontroluje swoje życie. A tymczasem jego świat właśnie rozpadał się na kawałki.

Wszedł na salę, uśmiechnął się do studentów i rozpoczął wykład.

— Dziś chciałbym porozmawiać o pewnym paradoksie — zaczął, a jego głos był zaskakująco pewny. — O tym, jak państwo, które miało być najpotężniejszą machiną wojenną w historii, rozpoczęło wojnę światową, mając zapasy amunicji na zaledwie sześć tygodni. Jak to możliwe?

Spojrzał na tablicę, na której wcześniej zapisał datę: 1 września 1939.

— Wiele osób wyobraża sobie III Rzeszę jako doskonale przygotowane imperium, które cierpliwie gromadziło siły przed uderzeniem. Ale prawda jest znacznie bardziej przerażająca. Niemcy w 1939 roku bały się nie wojny. Bały się pokoju.

---
## II. ROZWINIĘCIE

Adam wrócił do domu o 21:00. Mieszkanie na Mokotowie było ciche, ale nie tą ciszą, którą znał – była to cisza oczekiwania, napięcia, jak przed burzą. W salonie paliła się tylko mała lampka, przy której siedziała jego żona, Marta, z laptopem na kolanach.

— Usiądź — powiedziała, nie podnosząc wzroku.

Usiadł naprzeciwko niej. Przez chwilę patrzyli na siebie w milczeniu. Marta była kobietą o twarzy, która wiele widziała – czterdzieści trzy lata, dwójka dzieci, piętnaście lat małżeństwa. I teraz, w jej oczach, Adam zobaczył coś, czego bał się od tygodni: rozczarowanie.

— Znalazłam twoje wiadomości — powiedziała w końcu. — Do... do niej.

— Marto...

— Nie przerywaj mi. — Jej głos był spokojny, ale Adam wiedział, że to ten rodzaj spokoju, który poprzedza wybuch. — Czy to trwa długo?

— Trzy miesiące.

— Trzy miesiące. — Powtórzyła to słowo, jakby smakowała je na języku. — Trzy miesiące, w których wracałeś do domu, całowałeś mnie, rozmawiałeś z dziećmi, a jednocześnie... — Przerwała, zacisnęła usta. — Czy ona wie o mnie?

— Wie.

— I co? — zapytała. — Co jej powiedziałeś? Że jesteś nieszczęśliwy? Że ja cię nie rozumiem?

Adam milczał. W jego głowie pojawiło się wspomnienie – wykład, który prowadził tydzień temu, o jednym z kluczowych momentów II wojny światowej. O tym, jak Niemcy w 1938 roku, po aneksji Austrii, stanęli przed wyborem: dalej ekspansja albo wewnętrzny kryzys. Wybrali ekspansję.

_"System, który opiera się na ciągłym wzroście, nie może się zatrzymać"_ – mówił wtedy do studentów. _"Gdyby Niemcy zaprzestały ekspansji, musiałyby zmierzyć się z konsekwencjami własnego systemu. Ukryte długi, wyczerpane rezerwy, przegrzany przemysł. Zatrzymanie oznaczało zderzenie z rzeczywistością."_

Teraz, patrząc na Martę, zrozumiał, że mówił o sobie.

— Nie wiem, co ci powiedzieć — wyszeptał. — To nie miało być... to nie miało być tak, że cię zdradzam. Ja po prostu...

— Po prostu co? — przerwała mu. — Po prostu potrzebowałeś kogoś, kto cię zrozumie? Ktoś, kto nie jest zmęczony codziennością? Ktoś, kto nie ma dzieci, nie ma rachunków, nie ma problemów?

— Nie, to nie tak...

— To jak, Adam? — W jej głosie pojawiła się pierwsza nuta prawdziwej złości. — Jak to, że przez trzy miesiące kłamałeś mi każdego dnia? Jak to, że wracałeś do domu i udawałeś, że wszystko jest w porządku?

Adam poczuł, że coś w nim pęka. Przez ostatnie tygodnie żył w stanie permanentnego napięcia, jak człowiek, który wie, że zaraz spadnie z wysokości, ale nie może się zatrzymać. I teraz, kiedy wreszcie nadeszła ta chwila, nie wiedział, czy czuje ulgę, czy przerażenie.

— Marto... ja nie wiem, dlaczego to zrobiłem. Naprawdę nie wiem. To było jak... jakbym stał się kimś innym. Jakbym zobaczył siebie z zewnątrz i nie rozpoznał.

— To jest właśnie najgorsze — powiedziała cicho. — Że ty naprawdę nie wiesz.

---
## III. PUNKT ZWROTNY

Następnego dnia Adam nie poszedł na konferencję. Zamiast tego pojechał do archiwum, do swojego drugiego domu – miejsca, gdzie czuł się bezpieczny. Wśród stosów dokumentów, akt i książek o II wojnie światowej mógł udawać, że kontroluje rzeczywistość.

Siedział przy stoliku, przed nim otwarta była książka o niemieckiej gospodarce wojennej. Czytał o Halmarze Schachcie, który w 1937 roku ostrzegał Hitlera przed katastrofą. O ukrytych długach, o systemie weksli Mefo, o tym, jak Niemcy finansowały zbrojenia, pożyczając pieniądze, których nie miały.

_"System wchodzi w fazę, w której uratowanie go pokojową drogą jest niemal niemożliwe"_ – cytował Schachta.

Adam zamknął książkę i spojrzał w okno. Za szybą padał deszcz, a on myślał o swoim małżeństwie. O tym, jak przez piętnaście lat budował coś, co wydawało się stabilne, a teraz, gdy stanął w obliczu kryzysu, zrozumiał, że cała konstrukcja opierała się na czymś równie kruchej, co niemiecka gospodarka w 1939 roku – na nieustannym udawaniu, że wszystko jest w porządku.

Przypomniał sobie rozmowę z terapeutką, która prowadziła warsztaty o granicach w relacjach, na które wysłała go Marta rok temu. Mówiła wtedy coś, co zapamiętał:

_"Ludzie myślą, że w granicach chodzi o to, żeby mówić nie. Ale pytanie jest takie: czy ty wiesz, gdzie jest twoja granica? Bo tam, gdzie jest drugi człowiek, tam już mamy jakieś granice. I jeśli ich nie znamy, to prędzej czy później ktoś je przekroczy. Albo my je przekroczymy."_

Wtedy uznał to za banał. Teraz zrozumiał, że to była prawda.

Wziął telefon i napisał do Marty:

_"Wiem, że to nie wystarczy. Ale chcę spróbować to naprawić. Nie wiem jak. Ale chcę spróbować."_

Odpowiedziała po godzinie:

_"Przyjdź do domu. Porozmawiamy."_

---
## IV. DRUGI PUNKT ZWROTNY

Wieczorem Adam usiadł z Martą w salonie. Byli sami – dzieci u dziadków. Świece paliły się na stole, ale atmosfera nie była romantyczna, tylko poważna, jak przed ważną rozmową, która może zmienić wszystko.

— Chcę, żebyś mi powiedział jedną rzecz — zaczęła Marta. — I chcę, żebyś był szczery. Czy ty w ogóle chcesz być ze mną?

Adam milczał przez długą chwilę. W jego głowie pojawiły się słowa, które usłyszał kiedyś na wykładzie o psychologii zdrady: _"Zdrada prawie nigdy nie zaczyna się od wrogów. Zaczyna się od ludzi, których wpuszczamy do naszego życia."_

— Tak — powiedział w końcu. — Chcę być z tobą. Ale nie wiem, czy umiem.

— Co to znaczy?

— To znaczy, że przez ostatnie miesiące... ja się zgubiłem. Nie wiem, kiedy to się stało, ale przestałem wiedzieć, kim jestem. Przestałem wiedzieć, czego chcę. I zamiast powiedzieć ci o tym, poszedłem i zrobiłem coś, co zniszczyło twoje zaufanie.

Marta patrzyła na niego przez chwilę, a potem powiedziała coś, czego się nie spodziewał:

— Ja też się zgubiłam.

— Co?

— Nie tylko ty, Adam. Ja też. Przez ostatnie lata czułam się coraz bardziej samotna w tym małżeństwie. Ty byłeś zajęty pracą, wykładami, konferencjami. A ja... ja miałam dzieci, dom, obowiązki. I w pewnym momencie zorientowałam się, że nie pamiętam, kiedy ostatnio rozmawialiśmy o czymś innym niż rachunki i harmonogramy.

Adam poczuł, że robi mu się zimno. Przez cały czas myślał, że to on był ofiarą – ofiarą rutyny, nudy, braku zrozumienia. A tymczasem Marta czuła to samo.

— Dlaczego mi nie powiedziałaś? — zapytał.

— A ty dlaczego mi nie powiedziałeś? — odparowała. — Myślisz, że jesteśmy inni? Każdy z nas ma swoje granice, Adam. I oboje pozwoliliśmy, żeby ktoś je przekroczył. Tylko że ty... ty wybrałeś zdradę. A ja wybrałam milczenie.

Usiadła obok niego i wzięła jego dłoń.

— Nie wiem, czy możemy to naprawić — powiedziała cicho. — Ale wiem, że jeśli nie spróbujemy, to będziemy żałować do końca życia. Tak jak Niemcy w 1939 roku.

Adam spojrzał na nią ze zdumieniem.

— Co?

— Słuchałam twoich wykładów — uśmiechnęła się smutno. — Nie zawsze, ale czasami. Pamiętam, co mówiłeś o tym, że III Rzesza rozpoczęła wojnę, bo bała się pokoju. Że system, który opiera się na nieustannej ekspansji, musi się rozwijać, bo inaczej się zawali. I pomyślałam sobie... to tak jak my. Przez piętnaście lat udawaliśmy, że wszystko jest w porządku, zamiast zatrzymać się i powiedzieć: "Hej, tu jest problem. Musimy to naprawić." I teraz, kiedy wreszcie się zatrzymaliśmy, cała konstrukcja się chwieje.

Adam poczuł, że chce mu się płakać. Nie ze smutku, ale z ulgi, że ktoś wreszcie zrozumiał.

— Marto... — zaczął.

— Nie mów nic — przerwała mu. — Po prostu posłuchaj. Nie wiem, czy dam radę ci zaufać. Nie wiem, czy nasze małżeństwo przetrwa. Ale wiem, że jeśli teraz uciekniemy, to będzie oznaczać, że całe te piętnaście lat było stracone. A ja nie chcę, żeby tak było.

Wzięła jego dłoń i ścisnęła.

— Zostańmy. I spróbujmy.

---
## V. ZAKOŃCZENIE

Minął rok. Adam i Marta przeszli terapię – razem i osobno. Nauczyli się rozmawiać o granicach, o potrzebach, o tym, co ich boli, a co daje im siłę. Adam przestał prowadzić podwójne życie. Marta przestała milczeć.

Podczas jednego z wykładów, które prowadził na Uniwersytecie, Adam opowiedział studentom historię, która nie była w żadnym podręczniku:

— Wiecie, przez długi czas myślałem, że II wojna światowa to historia o potędze. O tym, jak jedno państwo zdominowało Europę. Ale im więcej się o niej uczę, tym bardziej widzę w niej coś innego – historię o tym, co się dzieje, gdy system staje się zbyt wielki, by się zatrzymać. Gdy ludzie boją się pokoju bardziej niż wojny. Gdy zamiast rozmawiać o problemach, wybierają ekspansję, bo nie wiedzą, jak inaczej przetrwać.

Zrobił pauzę i spojrzał na salę. Wśród studentów zobaczył młode pary, które trzymały się za ręce, i pomyślał o swojej żonie, która czekała na niego w domu.

— I wiesz, co jest najstraszniejsze? — kontynuował. — To, że te same mechanizmy działają w naszych życiach. W relacjach, w małżeństwach, w rodzinach. Kiedy przestajemy rozmawiać, kiedy przestajemy stawiać granice, kiedy udajemy, że wszystko jest w porządku... to prędzej czy później coś pęka. I wtedy mamy wybór: albo wojnę, albo pokój.

Spojrzał na tablicę, na której wypisał cytat z Nietzschego:

_"Kto walczy z potworami, powinien uważać, by sam nie stał się potworem."_

— Myślę, że ta wojna, którą pamiętamy jako historię, to tak naprawdę opowieść o ludziach, którzy bali się spojrzeć sobie w oczy. O przywódcach, którzy bali się przyznać do słabości. O narodzie, który bał się pokoju. I o tym, co się dzieje, gdy zapominamy, że granice nie są po to, żeby je przekraczać, ale po to, żeby wiedzieć, gdzie jesteśmy my, a gdzie inni.

Zakończył wykład i wyszedł z sali. Na korytarzu czekała na niego Marta z kwiatami.

— Byłeś świetny — powiedziała.

— Słuchałaś?

— Zawsze słucham.

Uśmiechnął się i wziął ją za rękę.

— Chodźmy do domu.

Wyszli z budynku, a na zewnątrz świeciło słońce. Adam spojrzał w niebo i pomyślał o wszystkim, co przeszli. O tym, jak blisko byli katastrofy. I o tym, że udało im się zatrzymać, zanim było za późno.

_"Granice"_ – pomyślał. _"To nie jest słabość. To siła. Wiedzieć, gdzie się kończysz, a gdzie zaczyna się ktoś inny."_

Uścisnął dłoń Marty.

— Kocham cię — powiedział.

— Wiem — odpowiedziała. — I ja ciebie.

Poszli dalej, zostawiając za sobą historię, która mogła skończyć się inaczej. Ale tym razem wybrali pokój.

---
## VI. EPILOG

Kilka miesięcy później Adam otrzymał e-mail od jednego z studentów, który był na jego wykładzie o III Rzeszy. Młody człowiek pisał:

_"Panie doktorze, nie wiem, czy pan pamięta, ale byłem na pana wykładzie o tym, jak Niemcy bały się pokoju. Wtedy myślałem, że to tylko ciekawostka historyczna. Ale potem coś się wydarzyło w moim życiu – moja dziewczyna zdradziła mnie, a ja zrozumiałem, że cały czas udawałem, że wszystko jest w porządku, zamiast z nią rozmawiać. Nie wiem, czy to naprawimy, ale chciałem panu podziękować. Bo dzięki panu zrozumiałem, że czasami wojna zaczyna się w naszych własnych domach. I że jedynym sposobem, żeby ją powstrzymać, jest zatrzymać się i spojrzeć prawdzie w oczy."_

Adam przeczytał e-mail trzy razy. Potem odpisał:

_"Dziękuję. I pamiętaj: granice to nie mury. To drzwi, które mogą być otwarte, ale tylko dla tych, którzy wiedzą, jak zapukać."_

Wysłał wiadomość i spojrzał przez okno. Na zewnątrz padał deszcz, ale on czuł, że wreszcie jest w miejscu, w którym powinien być.

W domu czekała na niego Marta. I wiedział, że teraz, po wszystkim, będą potrafili rozmawiać.

Bo nauczył się jednej rzeczy, której nie znalazł w żadnym podręczniku historii: że najtrudniejsze wojny to te, które toczymy sami ze sobą. I że największym zwycięstwem jest umieć się zatrzymać.

---
**KONIEC**

---

## Quiz

**Quiz title:** Sprawdź zrozumienie

### Question 1

**Question:** Co Adam mówi studentom o III Rzeszy na początku wykładu?

**Answers:**
- A) Że miała zapasy amunicji na sześć lat
- B) Że bała się pokoju bardziej niż wojny
- C) Że nie planowała ekspansji
- D) Że była gotowa na długą wojnę

**Correct:** B
**Explanation:** Adam mówi, że Niemcy w 1939 roku bały się nie wojny, lecz pokoju.
**Text reference:** bały się pokoju

### Question 2

**Question:** Co Marta odkrywa na komputerze Adama?

**Answers:**
- A) Notatki do wykładu
- B) Wiadomości do innej kobiety
- C) List od studenta
- D) Projekt badawczy

**Correct:** B
**Explanation:** Marta mówi, że znalazła jego wiadomości do „niej”.
**Text reference:** Wiadomości do... do niej

### Question 3

**Question:** Ile trwała zdrada Adama według jego wyznania?

**Answers:**
- A) Rok
- B) Trzy miesiące
- C) Sześć miesięcy
- D) Dwa tygodnie

**Correct:** B
**Explanation:** Adam przyznaje, że trwało to trzy miesiące.
**Text reference:** Trzy miesiące

### Question 4

**Question:** Jak Marta porównuje ich małżeństwo do historii III Rzeszy?

**Answers:**
- A) Do zwycięstwa w wojnie
- B) Do systemu opartego na ekspansji, który boi się zatrzymać
- C) Do pokoju po wojnie
- D) Do dyplomacji

**Correct:** B
**Explanation:** Marta mówi, że udawali, że wszystko jest w porządku, zamiast zatrzymać się i naprawić problem.
**Text reference:** bały się pokoju

### Question 5

**Question:** Co Adam pisze studentowi w epilogu o granicach?

**Answers:**
- A) Że granice to mury
- B) Że granice to drzwi, które mogą być otwarte
- C) Że granice należy burzyć
- D) Że granice nie istnieją

**Correct:** B
**Explanation:** Odpowiada, że granice to nie mury, lecz drzwi dla tych, którzy wiedzą, jak zapukać.
**Text reference:** granice to drzwi


---

## Future Extensions

### Images
*(none)*

### Illustrations
*(none)*

### Audio narration
*(none)*

### Pronunciation
*(none)*

### Handwriting
*(none)*

### Exercises
*(none)*

### Vocabulary
*(none)*
