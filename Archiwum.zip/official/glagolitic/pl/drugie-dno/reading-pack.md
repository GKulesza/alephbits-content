# Drugie dno

## Metadata

**Pack ID:** `polish_drugie_dno`  
**Version:** 1.0.0  
**Edition version:** 1.0.0  

**Title:** Drugie dno  
**Subtitle:** Kortyzol, jelita i rozwód Darka  
**Blurb:** Darek trafia do dr Cubalskiej po skierowaniu od profesora Czupryniaka — nie na cukrzycę, lecz na „drugie dno”. Krzywa kortyzolu, dysbioza i oś jelitowo-mózgowa tłumaczą mgłę, wzdęcia i rozwód z Martą. Opowieść o ciele, które krzyczało latami, zanim ktoś go wysłuchał.

**Genres:** medicine, psychology, short_story  
**Series:** Collection Eight  
**Audience:** adult

**Difficulty:** 6 (of 8)  
**Reader difficulty:** ★★★★☆  
**Estimated reading time:** 10 minutes

**Publication date:** *(original — 2026)*  
**Historical period:** contemporary  

**Original language:** pl  
**Translation summary:** Drugie dno — Collection Eight official reading pack (Polish).  

**Writing system:** glagolitic  
**Recommended profile:** polish_default  
**Recommended level:** 4  

**Tags:** kortyzol, jelita, stres, Collection Eight  

**Keywords:** drugie dno, Cubalska, Darek, kortyzol, dysbioza  

**Cover family:** medicine

**Editorial notes:** Fikcja-opinia medyczna o medycynie funkcjonalnej; nie zastępuje porady lekarskiej. Powiązanie z „Dniem z reszty życia”.

**Inspiration:** Oś HPA, jelitowo-mózgowa; skierowanie od Czupryniaka.

---

**World:**
- objects: boat
- places: home, river

## Editorial Transparency

**Created by:** AlephBits Editorial  
**Editor:** AlephBits Editorial  
**LLM assisted:** yes  
**LLM model:** Claude  
**Human reviewed:** yes — 2026-07-12  
**Trust classification:** Popular science  
**License:** CC0 1.0 Universal (SPDX: CC0-1.0)  
**License URL:** https://creativecommons.org/publicdomain/zero/1.0/  
**Source block:** 22.03.2026 -> https://www.youtube.com/watch?v=oCX5erg9_KE  
**Revision notes:** Phase 102 import.

### Revision history

| Version | Date | Note |
|---------|------|------|
| 1.0.0 | 2026-07-12 | Collection editorial import (Phase 102) |

### Editorial history

| Date | Editor | Note |
|------|--------|------|
| 2026-07-12 | AlephBits Editorial | Phase 102 import; philosophy fit 3/5 — Ważny temat zdrowia psychosomatycznego; wymaga disclaimera opinion. |

---

## Sources

### Source 1: Collection Eight manuscript

**Author:** AlephBits Editorial (adaptation)  
**URL:** https://www.youtube.com/watch?v=oCX5erg9_KE  
**License:** CC0 1.0 Universal (text); source material per original availability  
**Retrieval date:** 2026-03-22  
**Availability:** adaptation  
**Deprecated:** no  
**Editor notes:** Materiał źródłowy wskazany w bloku source manuskryptu; tekst jest adaptacją redakcyjną.

---

## Text

**Drugie dno**

Doktor Magdalena Cubała odłożyła telefon i spojrzała na kalendarz wizyt. Za dwadzieścia minut miała przyjąć nowego pacjenta – mężczyznę po czterdziestce, skierowanego przez profesora Czupryniaka z Banacha. „Panie Darku, to nie cukrzyca. Niech pan idzie do dr Cubały, ona znajdzie drugie dno” – przeczytała w notatce od profesora i uśmiechnęła się pod nosem. Znała go od lat, jeszcze z czasów, gdy sama pracowała w systemie, zanim uciekła do medycyny funkcjonalnej. Czupryniak był jednym z niewielu lekarzy akademickich, którzy nie patrzyli na nią jak na szarlatankę, gdy mówiła o osi jelitowo-mózgowej czy krzywej kortyzolowej. „Ty szukasz przyczyn, a ja leczę skutki” – powiedział jej kiedyś przy kawie. „Dlatego do ciebie wysyłam tych, którym moje tabletki nie wystarczają.”

Darek przyszedł punktualnie. Był wysokim, przygarbionym mężczyzną z siwiejącymi skroniami i głębokimi cieniami pod oczami, które zdradzały więcej niż zmęczenie – zdradzały rezygnację. W ręku ściskał teczkę z wynikami badań, grubszą niż standardowa dokumentacja pacjenta z cukrzycą. Profesor musiał zrobić mu pełny przegląd.

– Panie Darku – zaczęła, gdy już usiadł naprzeciwko. – Zanim przejdziemy do wyników, proszę mi opowiedzieć swoją historię. Nie tę medyczną. Tę życiową.

Mężczyzna spojrzał na nią nieufnie. Potem wzruszył ramionami.

– Rozwiodłem się. Pół roku temu. Żona... była żona. Nie wytrzymała. Mówiła, że się zmieniłem. Że już nie jestem tym samym człowiekiem, co kiedyś. Że tylko pracuję, a jak wracam do domu, to jestem jak zombi. – Przełknął ślinę. – Miała rację. Tylko ja wtedy nie wiedziałem dlaczego. Myślałem, że to lenistwo, wypalenie, może depresja. Chodziłem po lekarzach, brałem antydepresanty, nic nie pomagało. Mgła w głowie, zero energii. Rano budziłem się zmęczony, jakbym w ogóle nie spał. Piłem kawę za kawą. Wieczorem pękała mi głowa. A tu... – wskazał na brzuch – ciągle wzdęcia, gazy, raz zaparcia, raz biegunki. Myślałem, że to przez stres w pracy. Że samo przejdzie.

Magdalena słuchała, nie przerywając. Kiedy skończył, otworzyła teczkę i rozłożyła wyniki na biurku.

– Profesor Czupryniak wykluczył cukrzycę, insulinooporność, choroby tarczycy, anemię. Wszystkie podstawowe badania ma pan w normie. Prawie wszystkie. – Wskazała palcem na jedno z nich. – Zrobił panu krzywą kortyzolową ze śliny. Wie pan, co to jest?

– Profesor mówił, że to badanie poziomu stresu. Ale nie rozumiem... Stres? Każdy ma stres. Nie można przez to nie spać, nie myśleć, mieć rozwalone jelita.

– Można. – Przesunęła w jego stronę wydruk z wykresem. – Proszę spojrzeć. U zdrowego człowieka kortyzol rano jest najwyższy – to on pomaga nam wstać, poczuć energię. Potem powoli spada, żeby wieczorem osiągnąć minimum i pozwolić zasnąć. U pana jest odwrotnie. Rano kortyzol ledwo zipie, dlatego budzi się pan zmęczony. Za to wieczorem, około siedemnastej, osiemnastej, wystrzeliwuje w górę. Wtedy ma pan te bóle głowy, tę niemożność odprężenia się. A w nocy, kiedy powinien pan spać, kortyzol znowu rośnie. Dlatego przewraca się pan z boku na bok i nie może zasnąć, mimo że jest pan wykończony.

Darek wpatrywał się w wykres, jakby widział go po raz pierwszy. Może zresztą widział – profesor pewnie pokazał mu to samo, ale wtedy nie dotarło.

– To się nazywa rozregulowanie osi HPA – ciągnęła Magdalena. – Podwzgórze, przysadka, nadnercza. Kiedy jesteśmy zestresowani – nie przez tydzień, nie przez miesiąc, tylko przez lata – ten system się psuje. Jak silnik, który cały czas pracuje na najwyższych obrotach. W końcu się zaciera. I wtedy kortyzol przestaje słuchać rytmu dobowego. Jest go za mało, gdy trzeba wstać. Za dużo, gdy trzeba zasnąć. I to jest dopiero początek.

Odwróciła kartkę.

– Zrobił pan też badanie mikrobiomu. I tu jest druga część odpowiedzi. Ma pan zespół dysbiozy jelitowej. Mówiąc prościej: nieprawidłową florę bakteryjną. Za dużo bakterii, które produkują toksyny, za mało tych, które chronią jelita. Pod wpływem przewlekłego stresu zwiększa się przepuszczalność jelit – to znaczy, że to, co powinno zostać w jelitach, przedostaje się do krwi. Toksyny, niestrawione resztki, produkty fermentacji. I one idą prosto do mózgu. Wie pan, co to jest zespół własnego browaru?

– Nie.

– To stan, w którym grzyby z rodzaju candida produkują w jelitach alkohol. Dosłownie. Człowiek jest jakby cały czas lekko upojony. Mgła mózgowa, zmęczenie, problemy z koncentracją – wszystko się zgadza. Nie wiem, czy pan to ma akurat, ale dysbioza, którą pan ma, daje bardzo podobne objawy. Do tego dochodzi kwas mlekowy produkowany przez nieprawidłowe bakterie – też uderza w mózg.

Darek milczał. Jego dłonie, splecione na kolanach, zbielały od zaciskania.

– Czyli... to wszystko jest w jelitach? – zapytał w końcu.

– W jelitach i w głowie. A raczej między nimi. Oś jelitowo-mózgowa to dwukierunkowa autostrada. Nerw błędny łączy mózg z jelitami i przekazuje sygnały w obie strony. Kiedy pan się stresuje, mózg wysyła sygnał do jelit: „Uwaga, niebezpieczeństwo!”. Jelita się kurczą, zmienia się ich przepuszczalność, zmienia się mikrobiom. A kiedy jelita są chore, wysyłają sygnały do mózgu: „Jest źle”. I mózg znowu się stresuje. I tak w kółko. Błędne koło.

– Czyli to dlatego Marta...

Urwał. Magdalena nie ponaglała go. Wiedziała, że to, co za chwilę padnie, jest najważniejszym zdaniem tej wizyty.

– Marta, moja żona, mówiła, że się zmieniłem. Że nic mnie nie cieszy. Że jestem cyniczny, obojętny. Że nawet się nie kłócimy, tylko mijamy. A ja... ja nie miałem siły się kłócić. Nie miałem siły na nic. Myślałem, że to ona przesadza. Że gdyby trochę odpuściła, to byłoby lepiej. A teraz widzę... – Podniósł wzrok na Magdalenę. – To ja się popsułem. Dosłownie.

Magdalena odłożyła wyniki i spojrzała mu prosto w oczy.

– Panie Darku. To nie jest pana wina. Nikt panu nie powiedział, że organizm ma swoje granice. Że stres to nie jest coś, co można ignorować, bo on się wpisuje w ciało. Dosłownie. Kortyzol mówi tarczycy: „Zwalniamy metabolizm, bo jest zagrożenie”. Mówi hormonom płciowym: „Nie będziemy się rozmnażać, bo to nie czas”. Mówi układowi odpornościowemu: „Wyłączamy obronę, bo musimy uciekać przed tygrysem”. Tylko że pan nie uciekał przed tygrysem. Pan siedział przed komputerem, scrollował telefon, oglądał seriale do północy i codziennie słyszał od szefa, że cele nie są zrealizowane. Pana organizm myślał, że jest w stanie permanentnego oblężenia. A oblężone twierdze w końcu padają.

Darek otarł oczy wierzchem dłoni. Nie płakał – nie był w stanie. Ale coś w jego twarzy pękło, jakby pierwszy raz od lat dotarła do niego prawda.

– Co mam robić? – zapytał.

– Zacząć od prostych rzeczy. I to nie są żadne czary. Po pierwsze, rytm. Stałe pory posiłków. Cztery dziennie, żadnych przekąsek między nimi. Pana jelita potrzebują drużyny sprzątającej – to się nazywa migrujący kompleks motoryczny. Kiedy pan podjada, drużyna nie ma szans posprzątać resztek. I robi się bałagan.

– Po drugie, jedzenie bez ekranów. Zero laptopa, zero telefonu. Pierwsza faza trawienia jest w głowie – kiedy pan widzi jedzenie, wącha je, mózg przygotowuje układ trawienny do pracy. Jeśli w tym czasie scrolluje pan maile, mózg nie wie, że pan je. Trawienie idzie w krzaki.

– Po trzecie, spacery. Codziennie. Minimum pół godziny. Nie musi pan biegać, nie musi pan kupować karnetu na siłownię. Ma pan psa?

– Nie.

– To będzie pan wyprowadzał wirtualnego psa. Proszę sobie wyobrazić, że ma pan labradora, który musi wyjść trzy razy dziennie. Deszcz, śnieg, wiatr – nieważne. Pies nie czeka na ładną pogodę.

Darek prawie się uśmiechnął. Prawie.

– Po czwarte, higiena snu. Godzinę przed snem żadnych ekranów. Półmrok. Może pan słuchać chilloutu, może pan czytać książkę – papierową. Niebieskie światło z telefonu i laptopa rozregulowuje melatoninę. A pan już ma rozregulowaną.

– I po piąte, najtrudniejsze. Emocje. One też są biologiczne. Kiedy trzyma pan w sobie urazę, kiedy nie może pan odpuścić gniewu, to pana ciało cały czas produkuje kortyzol. Cały czas jest w stanie wojny. Zna pan taką historię? Kobieta dzwoni do przyjaciółki i żali się, że ktoś ją skrzywdził. A przyjaciółka pyta: „Po co ci te emocje? Kto cię teraz krzywdzi – tamte osoby czy ty sama? Bo tamci już dawno o tobie zapomnieli, a ty swoją złością i rozpaczą krzywdzisz tylko siebie. I tych, którzy są blisko ciebie.”

Darek drgnął. To zdanie uderzyło go mocniej niż wszystkie medyczne wyjaśnienia.

– Ja... ja chyba właśnie to robiłem. Przez ostatnie lata. Krzywdziłem siebie. I Martę. Bo nie umiałem puścić. Pracy, presji, oczekiwań. Wszystkiego.

– Puścić to nie znaczy zapomnieć – powiedziała Magdalena cicho. – To znaczy przestać karmić emocję, która niszczy pana od środka. Ta metoda nazywa się Metodą Sedony, może pan o niej poczytać. Ale na początek wystarczy jedno ćwiczenie. Jak poczuje pan, że wraca stara złość, stary żal, niech pan zada sobie pytanie: „Czy jestem gotów puścić tę emocję?”. Nie musi pan od razu umieć. Wystarczy, że pan spróbuje. Że pan powie: „Tak, jestem gotów”. I niech pan wtedy zrobi coś zupełnie innego niż zwykle. Wyjdzie na spacer. Pooddycha. Popatrzy na drzewo za oknem.

– A leki? – zapytał Darek. – Da mi pani coś na to wszystko?

– Dam. Adaptogeny na wyciszenie, probiotyki na jelita, magnez, bo w stresie traci go pan jak szalony. Ale to nie są leki, które pana wyleczą. To są podpórki. Fundament musi pan zbudować sam. Styl życia. Codzienność. Bez tego żaden suplement nie pomoże.

Darek wziął receptę i stał chwilę przy drzwiach, jakby chciał coś jeszcze powiedzieć. W końcu odwrócił się.

– Myśli pani, że mógłbym... mógłbym jeszcze to odkręcić? Nie chorobę. Resztę.

Magdalena spojrzała na niego z czymś, co nie było litością, tylko szacunkiem – takim, jaki ma się dla pacjentów, którzy wreszcie zadają właściwe pytanie.

– Panie Darku. Pana organizm krzyczał od dawna. Najpierw mgłą w głowie, potem jelitami, potem zmęczeniem. Pan go nie słuchał. I teraz on mówi głośniej. Ale to nie znaczy, że jest za późno. To znaczy, że trzeba zacząć go słuchać. A co do reszty... – Zawahała się. – Ja jestem lekarzem, nie terapeutą par. Ale jedno panu powiem. Ciało pamięta wszystko, co mu robimy. Jeśli pan je naprawi, jeśli pan odzyska energię, jasność myślenia, równowagę – będzie pan innym człowiekiem. I być może będzie pan gotowy na nowy związek. Z tą samą osobą lub z inną. Ale najpierw musi pan odzyskać siebie. Bo jak można dać komuś coś, czego samemu się nie ma?

Darek wyszedł. Magdalena odprowadziła go wzrokiem do drzwi, po czym usiadła przy biurku i zanotowała kilka rzeczy w karcie pacjenta. Potem podeszła do okna. Za szybą padał deszcz, ale w oddali, nad dachami bloków, przejaśniało się. Pomyślała o swoim wujku, chirurgu, który zmarł na zawał po trzydziestu latach pracy na NFZ. O młodym mężczyźnie, który wspinał się po szczeblach korporacji i dostał wylewu w wieku trzydziestu ośmiu lat. O sobie sprzed kilku lat, kiedy nie mogła wstać z łóżka z powodu bólu kręgosłupa i myślała, że jej życie się skończyło. Wtedy, w tym bólu, też musiała nauczyć się wdzięczności – za ptaki za oknem, za kota śpiącego na poduszce, za szklankę ciepłej wody rano, która jako jedyna nie powodowała skurczu żołądka.

Zdrowie jest cenniejsze niż miliony – pomyślała. I uśmiechnęła się do siebie, bo za godzinę miała kolejnego pacjenta. Kolejną historię. Kolejną szansę, by znaleźć drugie dno.

**KONIEC**

---

## Quiz

**Quiz title:** Sprawdź zrozumienie

### Question 1

**Question:** Kto skierował Darka do dr Cubalskiej?

**Answers:**
- A) Marta
- B) Profesor Czupryniak
- C) Psycholog
- D) Szef

**Correct:** B
**Explanation:** Notatka: profesor Czupryniak mówi — to nie cukrzyca, idź do dr Cubalskiej.
**Text reference:** profesor Czupryniaka

### Question 2

**Question:** Co jest nieprawidłowe u Darka w krzywej kortyzolu?

**Answers:**
- A) Za wysoki rano
- B) Rano kortyzol ledwo „zipie”, wieczorem wystrzeliwuje
- C) Brak kortyzolu
- D) Stały poziom

**Correct:** B
**Explanation:** Magdalena tłumaczy odwrócony rytm dobowy kortyzolu.
**Text reference:** odwrotnie

### Question 3

**Question:** Co Magdalena mówi o osi jelitowo-mózgowej?

**Answers:**
- A) Że nie istnieje
- B) Że to dwukierunkowa autostrada — stres psuje jelita, chore jelita stresują mózg
- C) Że dotyczy tylko dzieci
- D) Że leczy ją antybiotyk

**Correct:** B
**Explanation:** Opisuje błędne koło między stresem a jelitami.
**Text reference:** błędne koło

### Question 4

**Question:** Co Darek przyznaje o rozwodzie z Martą?

**Answers:**
- A) Że Marta była winna
- B) Że nie miał siły się kłócić i myślał, że ona przesadza — a teraz widzi, że się „popsuł”
- C) Że nigdy jej nie kochał
- D) Że wróci do niej

**Correct:** B
**Explanation:** Mówi: to ja się popsułem dosłownie.
**Text reference:** popsułem

### Question 5

**Question:** Co Magdalena mówi o emocjach i kortyzolu?

**Answers:**
- A) Że emocje nie mają znaczenia
- B) Że trzymanie urazy produkuje kortyzol — ciało cały czas jest w stanie wojny
- C) Że trzeba je tłumić
- D) Że tylko leki pomagają

**Correct:** B
**Explanation:** Mówi o emocjach produkujących kortyzol i stanie oblężenia.
**Text reference:** stanie wojny


---

## Future Extensions

### Images
*(none)*

### Illustrations
*(none)*

### Audio narration
*(none)*

### Pronunciation
*(none)*

### Handwriting
*(none)*

### Exercises
*(none)*

### Vocabulary
*(none)*
